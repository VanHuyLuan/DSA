#include<iostream>
#include<stack>
using namespace std;

class Queue{
private:
	stack<int> q1;
	stack<int> q2;
public:
	void enqueue(int x)
	{
		q1.push(x);
	}
	
	void dequeue()
	{
		int n = q1.size();
		while(n > 0)
		{
			q2.push(q1.top());
			q1.pop();
			n--;
		}
		cout << "dequeue: " << q2.top() << endl;
		q2.pop();
	}
};

int main()
{
	Queue myqueue;
	myqueue.enqueue(1);
	myqueue.enqueue(2);
	myqueue.enqueue(3);
	myqueue.enqueue(4);
	myqueue.dequeue();
	myqueue.dequeue();
	myqueue.enqueue(5);
	return 0;
}
