
#include <iostream>
#include <queue>
using namespace std;

class Stack {
private:
    queue<int> q1;
    queue<int> q2;
public:
    void push(int x) {
        q1.push(x);
    }

    void pop() {
        while (q1.size() > 1) {
            q2.push(q1.front());
            q1.pop();
        }
        cout << "pop: " << q1.front() << endl; 
        q1.pop();
        swap(q1, q2); 
    }

    int top() {
        while (q1.size() > 1) {
            q2.push(q1.front());
            q1.pop();
        }
        int value = q1.front();
        q2.push(value);
        swap(q1, q2); 
        return value;
    }
};

int main() {
    Stack mystack;
    mystack.push(1);
    mystack.push(2);
    mystack.push(3);
    mystack.push(4);
    //cout << "Top: " << mystack.top() << endl;
    mystack.pop();
    //cout << "Top after pop: " << mystack.top() << endl;
    mystack.pop();
    mystack.push(5);
    return 0;
}
